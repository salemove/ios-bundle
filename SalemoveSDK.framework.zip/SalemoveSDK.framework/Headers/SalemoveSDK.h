//

#import <UIKit/UIKit.h>

//! Project version number for SalemoveSDK.
FOUNDATION_EXPORT double SalemoveSDKVersionNumber;

//! Project version string for SalemoveSDK.
FOUNDATION_EXPORT const unsigned char SalemoveSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SalemoveSDK/PublicHeader.h>
